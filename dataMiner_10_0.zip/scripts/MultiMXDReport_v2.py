# Author:  ESRI & Tetra Tech (Ehren Hill)
# Date:    February 11, 2013
# Version: ArcGIS 10.1
# Purpose: This script will iterate through each MXD in a folder (and all recursive folders) and report information about each
#          map document, its data frames and its layers.  The script is intended to run from a script
#          tool that requires two input parameters:
#               1) folder containing MXDs,
#               2) an output text file.
#          The resulting text file will automatically open.

import arcpy, datetime, os
arcpy.gp.overwriteOutput = True

try:   
    #Read input parameters from GP dialog
    folderPath = arcpy.GetParameterAsText(0)
    output = arcpy.GetParameterAsText(1)

    #Create an output file
    outFile = open(output, "w")

    #Report header
    outFile.write("MXD REPORT: \n")
    outFile.write("\n")
    outFile.write("This report is for all MXDs in a folder.  It lists relevant information about\n")
    outFile.write("map document properties, data frame, layer, and table information for each MXD\n")
    outFile.write("in a system folder\n")
    outFile.write("\n")
    outFile.write("Date: " + str(datetime.datetime.today().strftime("%B %d, %Y")) + "\n")

    #Loop through each MXD file
    count = 0
    for (path, dirs, files) in os.walk(folderPath):
        for file in files:
            if file.lower().endswith(".mxd"):
                #Reference MXD
                mxd = arcpy.mapping.MapDocument(os.path.join(path, file))
                count = 1

                #Format output value
                if mxd.author =="": authorValue = "None"
                else: authorValue = mxd.author
                if mxd.summary =="": summaryValue = "None"
                else: summaryValue = mxd.summary
                BDS = arcpy.mapping.ListBrokenDataSources(mxd)
                if len(BDS) == 0: BDSValue = "None"
                else: BDSValue = "A total of " + str(len(BDS)) + " broken data source(s)."
                
                #Write MXD data to file
                outFile.write("\n")
                outFile.write("\n")
                outFile.write("------------------------------------------------------------------- \n")
                outFile.write("MAPDOCUMENT: " + os.path.basename(mxd.filePath) + "\n")
                outFile.write("------------------------------------------------------------------- \n")
                outFile.write("\n")

                try:
                    outFile.write("\t Path:                 " + mxd.filePath + "\n")
                    outFile.write("\t Last Saved:           " + str(mxd.dateSaved) + "\n")
                    outFile.write("\t Author:               " + authorValue + "\n")
                    outFile.write("\t Summary:              " + summaryValue + "\n")
                    outFile.write("\t Relative Paths:       " + str(mxd.relativePaths) + "\n")
                    outFile.write("\t Broken Data Sources:  " + BDSValue + "\n")

                    #Reference each data frame and report data
                    DFList = arcpy.mapping.ListDataFrames(mxd)
                    for df in DFList:
                        #Format output values
                        if df.description == "": descValue = "None"
                        else: descValue = df.description

                        #Write data frame data to file
                        outFile.write("\n")
                        outFile.write("\n")
                        try:
                            outFile.write("\t DATA FRAME: " + df.name + "\n")
                        except:
                            outFile.write("\t DATA FRAME: UNKNOWN (DATA FRAME NAME MIGHT CONTAIN SPECIAL CHARACTERS AND CAN NOT BE WRITTEN TO A TEXT FILE)" + "\n")
                        outFile.write("\n")
                        outFile.write("\t\t Description:        " + descValue + "\n")
                        outFile.write("\t\t Spatial Reference:  " + df.spatialReference.name + "\n")
                        outFile.write("\t\t Transformation(s):  " + str(df.geographicTransformations) + "\n")
                        outFile.write("\t\t Map Units:          " + df.mapUnits + "\n")
                        try:
                            outFile.write("\t\t Scale:              " + str(df.scale) + "\n")
                        except:
                            outFile.write("\t\t Scale:              Unknown \n")
                        outFile.write("\t\t Rotation:           " + str(df.rotation) + "\n")
                      
                        #Reference each layer in a data frame
                        lyrList = arcpy.mapping.ListLayers(mxd, "", df)
                        for lyr in lyrList:
                            outFile.write("\n")
                            try:
                                outFile.write("\t\t LAYER: " + lyr.name + "\n")
                            except:
                                outFile.write("\t\t LAYER: UNKNOWN (LAYER NAME MIGHT CONTAIN SPECIAL CHARACTERS AND CAN NOT BE WRITTEN TO A TEXT FILE)" + "\n")
                            try:
                                outFile.write("\t\t\t Group Layer Path:  " + lyr.longName + "\n")
                            except:
                                outFile.write("\t\t\t Group Layer Path: UNKNOWN (GROUP LAYER PATH MIGHT CONTAIN SPECIAL CHARACTERS AND CAN NOT BE WRITTEN TO A TEXT FILE)" + "\n")
                            if lyr.supports("dataSource"):
                                outFile.write("\t\t\t Data Source:       " + lyr.dataSource + "\n")
                                try:
                                    outFile.write("\t\t\t Dataset type:      " + arcpy.Describe(lyr.dataSource).datasettype + "\n")
                                except:
                                    outFile.write("\t\t\t Dataset type:      Unknown (could be a broken data source) \n")
                            else: outFile.write("\t\t\t Data Source:       N/A \n")
                            try:
                                if lyr.supports("definitionQuery"):
                                    if lyr.definitionQuery == "":
                                        outFile.write("\t\t\t Query Definition:  None \n" )
                                    else: outFile.write("\t\t\t Query Definition:  " + lyr.definitionQuery + "\n")
                                else: outFile.write("\t\t\t Query Definition:  N/A \n")
                            except:
                                outFile.write("\t\t\t Query Definition:  UNKNOWN (QUERY DEFINITION MIGHT CONTAIN SPECIAL CHARACTERS AND CAN NOT BE WRITTEN TO A TEXT FILE)" + "\n")
                            if lyr.visible == True:
                                outFile.write("\t\t\t Layer Visible:     Yes \n")
                            else:
                                outFile.write("\t\t\t Layer Visible:     No \n")
                            if lyr.supports("labelClasses"):
                                if lyr.showLabels:
                                    outFile.write("\t\t\t Labels Visible:    Yes \n")
                                    try:
                                         for lblClass in lyr.labelClasses:
                                            if lblClass.showClassLabels:
                                                outFile.write("\t\t\t\t Label Class Name:  " + lblClass.className + "\n" )
                                                outFile.write("\t\t\t\t Label Expression:  " + lblClass.expression + "\n" )
                                                if lblClass.SQLQuery:
                                                    outFile.write("\t\t\t\t Label SQL Query:  " + lblClass.SQLQuery + "\n" )
                                                else:
                                                    outFile.write("\t\t\t\t Label SQL Query:   None\n" )
                                    except:
                                        outFile.write("\t\t\t\t Label: UNKNOWN (LABEL DETAILS MIGHT CONTAIN SPECIAL CHARACTERS AND CAN NOT BE WRITTEN TO A TEXT FILE)" + "\n")
                                else:
                                    outFile.write("\t\t\t Labels Visible:    No \n")
                            else:
                                outFile.write("\t\t\t Labels Visible:    N/A \n")
                            try:
                                if lyr.supports("symbology"):
                                    outFile.write("\t\t\t Symbology Type:    "+ lyr.symbologyType + "\n")
                                    if lyr.symbologyType == 'UNIQUE_VALUES':
                                        outFile.write("\t\t\t\t Symbology Value Field:   " + lyr.symbology.valueField + "\n")
                                        outFile.write("\t\t\t\t Symbology Class Values:  " + str(lyr.symbology.classValues)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Class Labels:  " + str(lyr.symbology.classLabels)+ "\n")
                                    elif lyr.symbologyType == 'GRADUATED_COLORS':
                                        outFile.write("\t\t\t\t Symbology Value Field:                " + lyr.symbology.valueField + "\n")
                                        outFile.write("\t\t\t\t Symbology Normalization:              " + str(lyr.symbology.normalization)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Number Of Classifications:  " + str(lyr.symbology.numClasses)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Class Break Values:         " + str(lyr.symbology.classBreakValues)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Class Break Labels:         " + str(lyr.symbology.classBreakLabels)+ "\n")
                                    elif lyr.symbologyType == 'GRADUATED_SYMBOLS':
                                        outFile.write("\t\t\t\t Symbology Value Field:                " + lyr.symbology.valueField + "\n")
                                        outFile.write("\t\t\t\t Symbology Normalization:              " + str(lyr.symbology.normalization)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Number Of Classifications:  " + str(lyr.symbology.numClasses)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Class Break Values:         " + str(lyr.symbology.classBreakValues)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Class Break Labels:         " + str(lyr.symbology.classBreakLabels)+ "\n")
                                    elif lyr.symbologyType == 'RASTER_CLASSIFIED':
                                        outFile.write("\t\t\t\t Symbology Value Field:                " + lyr.symbology.valueField + "\n")
                                        outFile.write("\t\t\t\t Symbology Normalization:              " + str(lyr.symbology.normalization)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Number Of Classifications:  " + str(lyr.symbology.numClasses)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Class Break Values:         " + str(lyr.symbology.classBreakValues)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Class Break Labels:         " + str(lyr.symbology.classBreakLabels)+ "\n")
                                        outFile.write("\t\t\t\t Symbology Excluded Values:            " + str(lyr.symbology.excludedValues)+ "\n")
                                else:
                                    outFile.write("\t\t\t Symbology Type:    OTHER (e.g., Default, Unique Values Many Fields, Proportional Symbols, Charts, etc.) \n")
                            except:
                                outFile.write("\t\t\t Symbology Type:    Symbology Not Supported\n")
                        #Reference each table in a data frame 
                        tableList = arcpy.mapping.ListTableViews(mxd, df, "")
                        for table in tableList:
                            outFile.write("\n")
                            outFile.write("\n")
                            outFile.write("\t\t TABLEVIEW: " + table.name + "\n")
                            outFile.write("\n")
                            outFile.write("\t\t\t Data Source:           " + table.dataSource + "\n")
                            if table.definitionQuery == "":
                                outFile.write("\t\t\t Query Definition:      None \n")
                            else: outFile.write("\t\t\t Query Definition:      " + table.definitionQuery + "\n")

                    del mxd, BDS, DFList, lyrList, tableList
                except:
                    outFile.write("\t THIS MXD MIGHT CONTAIN SPECIAL CHARACTERS AND THE DETAILS CAN NOT BE WRITTEN TO A TEXT FILE" + "\n")
    if count ==0:
        outFile.write("\n")
        outFile.write("\n")
        outFile.write("---------------------------------------------------------------------------------- \n")
        outFile.write("                            NO MXD FILES FOUND \n")
        outFile.write("---------------------------------------------------------------------------------- \n")                          

    outFile.close()

    #Open resulting text file
    os.startfile(output)

    #Delete variables that reference data on disk
    del folderPath, output, outFile

except Exception, e:
  import traceback
  print e.message
  map(arcpy.AddError, traceback.format_exc().split("\n"))
  arcpy.AddError(str(e))