# Author:  Ehren Hill - Tetra Tech
# Date:    April 1, 2013
# Version: ArcGIS 10.1 and 10.0
# Purpose: This script will iterate through each GIS file in a folder (and all recursive folders) and report information
# about each layer's fields.  The script is intended to run from a script tool inside an ArcGIS Toolbox.  The script requires two
# user input values:
#   1. An input folder
#   2. An output Excel File


try:
    #Setup environment and import modules
    import xlwt, os, arcpy
    arcpy.env.overwriteOutput = True


    #Get user input parameters, please note that the inputFolder cannot contain any GIS files, or they will not be read
    inputFolder = arcpy.GetParameterAsText(0)
    outputFile = arcpy.GetParameterAsText(1)


    #Create workbook with one sheet named Output
    wb = xlwt.Workbook()
    ws = wb.add_sheet('Output')


    #Create list of column names in the workbook
    headerNamesList = ['ID', 'Feature Name', 'Feature Path', 'Feature Type', 'Object Type','Feature Count', 'Field Name', 'Field Type',
                   'Field Length']

    headerColumn = 0
    for name in headerNamesList:
        ws.write(0,headerColumn, name)
        headerColumn = headerColumn + 1
        

    #Create empty global lists and other global variables
    fcList = []
    tableList = []
    excelRow = 1


    #Searches through all folders for GIS files
    for dir, folderNames, fileNames in os.walk(inputFolder):
        for subFolderName in folderNames:
            arcpy.env.workspace = os.path.join(dir, subFolderName)
            datasetList = arcpy.ListDatasets()
            workspaceList = arcpy.ListWorkspaces()
            fcList = arcpy.ListFeatureClasses()
            tableList = arcpy.ListTables()

            print "Processing Folder: " + os.path.join(dir, subFolderName)
            arcpy.AddMessage("Processing Folder: " + os.path.join(dir, subFolderName))

            #Checks for feature classes in feature datasets (this also includes coverages and CAD files)
            for dataset in datasetList:
                for fc in arcpy.ListFeatureClasses('', '', dataset):
                    try:
                        print "     Processing File: " + os.path.join(dataset, fc)
                        arcpy.AddMessage("     Processing File: " + os.path.join(dataset, fc))
                        #Setup variables for textToWriteList and check for valid metadata values
                        if arcpy.Describe(dataset).dataType == "Coverage" or arcpy.Describe(dataset).dataType == "CadDrawingDataset":
                            desc = arcpy.Describe(dataset + "/" + fc)
                        else:
                            desc = arcpy.Describe(fc)
                        fcPath = os.path.join(dir, subFolderName, dataset)
                        fcDataType = desc.dataType
                        fcShapeType = desc.shapeType
                        if arcpy.Describe(dataset).dataType == "Coverage" or arcpy.Describe(dataset).dataType == "CadDrawingDataset":
                            fcFeatureCount = str(arcpy.GetCount_management(dataset + "/" + fc))
                            fieldList = arcpy.ListFields(dataset + "/" + fc)
                        else:
                            fcFeatureCount = str(arcpy.GetCount_management(fc))
                            fieldList = arcpy.ListFields(fc)

                        #fieldList = arcpy.ListFields(fc)
                        for field in fieldList:
                            fcFieldName = field.name
                            fcFieldType = field.type
                            fcFieldLength = field.length

                            #Create list to hold text values for writing to Excel                    
                            textToWriteList = [excelRow, fc, fcPath, fcDataType, fcShapeType, fcFeatureCount, fcFieldName, fcFieldType, fcFieldLength]

                            #Start writing information on fc and fields to Excel
                            column = 0
                            for text in textToWriteList:                    
                                row = ws.row(excelRow)
                                if len(str(text)) > 32760:
                                    text = "Value has too many characters to write"
                                    row.write(column, text)
                                    column = column + 1
                                else:
                                    row.write(column, text)
                                    column = column + 1

                            #Increment row counter by 1
                            excelRow = excelRow + 1
                    except:
                        print "     Could not process: " + fc + " at: " + os.path.join(dir, subFolderName, dataset) + "; Skipping"
                        arcpy.AddMessage("     Could not process: " + fc + " at: " + os.path.join(dir, subFolderName, dataset) + "; Skipping")
                        fcPath = os.path.join(dir, subFolderName,dataset, fc)
                        fcDataType = "COULD NOT PROCESS FILE"
                        #Create list to hold text values for writing to Excel                    
                        textToWriteList = [excelRow, fc, fcPath, fcDataType]

                        #Start writing information on fc and fields to Excel
                        column = 0
                        for text in textToWriteList:                    
                            row = ws.row(excelRow)
                            if len(str(text)) > 32760:
                                text = "Value has too many characters to write"
                                row.write(column, text)
                                column = column + 1
                            else:
                                row.write(column, text)
                                column = column + 1

                        #Increment row counter by 1
                        excelRow = excelRow + 1
                        

            #Checks for feature classes in personal geodatabases
            for workspace in workspaceList:
                #set environmental workspace to personal geodatabase
                arcpy.env.workspace = workspace
                for fc in arcpy.ListFeatureClasses():
                    try:
                        print "     Processing File: " + os.path.join(workspace, fc)
                        arcpy.AddMessage("     Processing File: " + os.path.join(workspace, fc))
                        #Setup variables for textToWriteList and check for valid metadata values
                        if arcpy.Describe(workspace).dataType == "Coverage" or arcpy.Describe(workspace).dataType == "CadDrawingDataset":
                            desc = arcpy.Describe(workspace + "/" + fc)
                        else:
                            desc = arcpy.Describe(fc)
                        fcPath = os.path.join(dir, subFolderName, workspace)
                        fcDataType = desc.dataType
                        fcShapeType = desc.shapeType
                        if arcpy.Describe(workspace).dataType == "Coverage" or arcpy.Describe(workspace).dataType == "CadDrawingDataset":
                            fcFeatureCount = str(arcpy.GetCount_management(workspace + "/" + fc))
                            fieldList = arcpy.ListFields(workspace + "/" + fc)
                        else:
                            fcFeatureCount = str(arcpy.GetCount_management(fc))
                            fieldList = arcpy.ListFields(fc)

                        #fieldList = arcpy.ListFields(fc)
                        for field in fieldList:
                            fcFieldName = field.name
                            fcFieldType = field.type
                            fcFieldLength = field.length

                            #Create list to hold text values for writing to Excel                    
                            textToWriteList = [excelRow, fc, fcPath, fcDataType, fcShapeType, fcFeatureCount, fcFieldName, fcFieldType, fcFieldLength]

                            #Start writing information on fc and fields to Excel
                            column = 0
                            for text in textToWriteList:                    
                                row = ws.row(excelRow)
                                if len(str(text)) > 32760:
                                    text = "Value has too many characters to write"
                                    row.write(column, text)
                                    column = column + 1
                                else:
                                    row.write(column, text)
                                    column = column + 1

                            #Increment row counter by 1
                            excelRow = excelRow + 1
                            #set workspace back to original environmental workspace
                            arcpy.env.workspace = os.path.join(dir, subFolderName)
                    except:
                        print "     Could not process: " + fc + " at: " + os.path.join(dir, subFolderName, workspace) + "; Skipping"
                        arcpy.AddMessage("     Could not process: " + fc + " at: " + os.path.join(dir, subFolderName, workspace) + "; Skipping")
                        fcPath = os.path.join(dir, subFolderName, workspace, fc)
                        fcDataType = "COULD NOT PROCESS FILE"
                        #Create list to hold text values for writing to Excel                    
                        textToWriteList = [excelRow, fc, fcPath, fcDataType]

                        #Start writing information on fc and fields to Excel
                        column = 0
                        for text in textToWriteList:                    
                            row = ws.row(excelRow)
                            if len(str(text)) > 32760:
                                text = "Value has too many characters to write"
                                row.write(column, text)
                                column = column + 1
                            else:
                                row.write(column, text)
                                column = column + 1

                        #Increment row counter by 1
                        excelRow = excelRow + 1
                        #set workspace back to original environmental workspace
                        arcpy.env.workspace = os.path.join(dir, subFolderName)
            #Read data for feature classes
            for fc in fcList:
                try:
                    print "     Processing File: " + fc
                    arcpy.AddMessage("     Processing File: " + fc)
                    #Setup variables for textToWriteList and check for valid metadata values
                    desc = arcpy.Describe(fc)
                    fcPath = desc.path
                    fcDataType = desc.dataType
                    fcShapeType = desc.shapeType
                    fcFeatureCount = str(arcpy.GetCount_management(fc))

                    fieldList = arcpy.ListFields(fc)
                    for field in fieldList:
                        fcFieldName = field.name
                        fcFieldType = field.type
                        fcFieldLength = field.length

                        #Create list to hold text values for writing to Excel                    
                        textToWriteList = [excelRow, fc, fcPath, fcDataType, fcShapeType, fcFeatureCount, fcFieldName, fcFieldType, fcFieldLength]

                        #Start writing information on fc and fields to Excel
                        column = 0
                        for text in textToWriteList:                    
                            row = ws.row(excelRow)
                            if len(str(text)) > 32760:
                                    text = "Value has too many characters to write"
                                    row.write(column, text)
                                    column = column + 1
                            else:
                                row.write(column, text)
                                column = column + 1

                        #Increment row counter by 1
                        excelRow = excelRow + 1 
                except:
                    print "     Could not process: " + fc + " at: " + os.path.join(dir, subFolderName) + "; Skipping"
                    arcpy.AddMessage("     Could not process: " + fc + " at: " + os.path.join(dir, subFolderName) + "; Skipping")
                    fcPath = os.path.join(dir, subFolderName, fc)
                    fcDataType = "COULD NOT PROCESS FILE"
                    #Create list to hold text values for writing to Excel                    
                    textToWriteList = [excelRow, fc, fcPath, fcDataType]

                    #Start writing information on fc and metadata to Excel
                    column = 0
                    for text in textToWriteList:                    
                        row = ws.row(excelRow)
                        if len(str(text)) > 32760:
                                text = "Value has too many characters to write"
                                row.write(column, text)
                                column = column + 1
                        else:
                            row.write(column, text)
                            column = column + 1

                    #Increment row counter by 1
                    excelRow = excelRow + 1


            #Read data for tables
            for table in tableList:
                try:
                    print "     Processing File: " + table
                    arcpy.AddMessage("     Processing File: " + table)

                    #Setup variables for textToWriteList and check for valid metadata values
                    desc = arcpy.Describe(table)
                    tablePath = desc.path
                    tableDataType = desc.dataType
                    tableShapeType = "N/A"  
                    tableFeatureCount = "N/A"

                    fieldList = arcpy.ListFields(table)
                    for field in fieldList:
                        tableFieldName = field.name
                        tableFieldType = field.type
                        tableFieldLength = field.length

                        #Create list to hold text values for writing to Excel                    
                        textToWriteList = [excelRow, table, tablePath, tableDataType, tableShapeType, tableFeatureCount, tableFieldName, tableFieldType, tableFieldLength]

                        #Start writing information on table and fields to Excel
                        column = 0
                        for text in textToWriteList:                    
                            row = ws.row(excelRow)
                            if len(str(text)) > 32760:
                                text = "Value has too many characters to write"
                                row.write(column, text)
                                column = column + 1
                            else:
                                row.write(column, text)
                                column = column + 1

                        #Increment row counter by 1
                        excelRow = excelRow + 1 
                except:
                    print "     Could not process: " + table + " at: " + os.path.join(dir, subFolderName) + "; Skipping"
                    arcpy.AddMessage("     Could not process: " + table + " at: " + os.path.join(dir, subFolderName) + "; Skipping")
                    tablePath = os.path.join(dir, subFolderName, table)
                    tableDataType = "COULD NOT PROCESS FILE"
                    #Create list to hold text values for writing to Excel                    
                    textToWriteList = [excelRow, table, tablePath, tableDataType]

                    #Start writing information on fc and metadata to Excel
                    column = 0
                    for text in textToWriteList:                    
                        row = ws.row(excelRow)
                        if len(str(text)) > 32760:
                                text = "Value has too many characters to write"
                                row.write(column, text)
                                column = column + 1
                        else:
                            row.write(column, text)
                            column = column + 1

                    #Increment row counter by 1
                    excelRow = excelRow + 1

    #Saves output
    wb.save(outputFile)

except Exception, e:
    import traceback
    print e.message
    map(arcpy.AddError, traceback.format_exc().split("\n"))
    arcpy.AddError(str(e))
    arcpy.AddMessage("This tool encountered a serious error and could not finish.")
  